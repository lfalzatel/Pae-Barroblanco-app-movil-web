'use client';

import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface MiniCalendarProps {
    selectedDate: string;
    onSelectDate: (date: string) => void;
    className?: string;
    highlightedDates?: string[]; // Optional: provide dates to highlight externally
    dateData?: Record<string, number>; // Optional: provide counts/data per date
    showCounters?: boolean; // New: whether to show numerical counters
    mode?: 'schedules' | 'attendance' | 'manual'; // Default is schedules
    onMonthChange?: (year: number, month: number) => void;
}

const toLocalISO = (d: Date) => {
    const offset = d.getTimezoneOffset() * 60000;
    return new Date(d.getTime() - offset).toISOString().split('T')[0];
};

export function MiniCalendar({
    selectedDate,
    onSelectDate,
    className = '',
    highlightedDates: externalDates,
    dateData,
    showCounters = true,
    mode = 'schedules',
    onMonthChange
}: MiniCalendarProps) {
    const [currentDate, setCurrentDate] = useState(() => {
        if (!selectedDate) return new Date();
        const [y, m, d] = selectedDate.split('-').map(Number);
        // Create date in local time (months are 0-indexed)
        const date = new Date(y, m - 1, d);
        return isNaN(date.getTime()) ? new Date() : date;
    });
    const [internalDates, setInternalDates] = useState<string[]>([]);
    const [loading, setLoading] = useState(mode === 'schedules');

    useEffect(() => {
        if (onMonthChange) {
            onMonthChange(currentDate.getFullYear(), currentDate.getMonth());
        }
    }, [currentDate.getMonth(), currentDate.getFullYear()]);

    useEffect(() => {
        if (mode === 'schedules') {
            fetchSchedules();
        } else {
            setLoading(false);
        }
    }, [currentDate.getMonth(), currentDate.getFullYear(), mode]);

    const fetchSchedules = async () => {
        setLoading(true);
        try {
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();

            const startStr = toLocalISO(new Date(year, month, 1));
            const endStr = toLocalISO(new Date(year, month + 1, 0));

            const { data } = await supabase
                .from('schedules')
                .select('date, items')
                .gte('date', startStr)
                .lte('date', endStr);

            if (data) {
                const datesWithSchedules = data.map(d => d.date);
                setInternalDates(datesWithSchedules);

                // If showCounters is on, build the count map
                if (showCounters) {
                    const counts: Record<string, number> = {};
                    data.forEach(d => {
                        const items = d.items as any[];
                        const newsCount = items ? items.filter((i: any) => i.notes || i.time === 'NO_ASISTE' || i.time_start === 'NO_ASISTE').length : 0;
                        counts[d.date] = newsCount;
                    });
                    // We need a way to pass this back or use it internally
                    // Since dateData is a prop, we'll merge it with internal logic or just use internalDates
                    // Let's actually update a local state for counts if we are in 'schedules' mode
                    setInternalCounts(counts);
                }
            }
        } catch (error) {
            console.error('Error fetching dates:', error);
        } finally {
            setLoading(false);
        }
    };

    const [internalCounts, setInternalCounts] = useState<Record<string, number>>({});

    const activeDates = mode === 'manual' || mode === 'attendance' ? (externalDates || []) : internalDates;

    const getDaysInMonth = (year: number, month: number) => {
        return new Date(year, month + 1, 0).getDate();
    };

    const getFirstDayOfMonth = (year: number, month: number) => {
        return new Date(year, month, 1).getDay();
    };

    const handlePrevMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    };

    const handleNextMonth = () => {
        setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    };

    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const daysInMonth = getDaysInMonth(year, month);
    const firstDay = getFirstDayOfMonth(year, month);

    const monthNames = [
        "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
        "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
    ];

    const generateIsoDate = (day: number) => {
        return `${year}-${(month + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    };

    const days = [];
    for (let i = 0; i < firstDay; i++) days.push(null);
    for (let i = 1; i <= daysInMonth; i++) days.push(i);

    const styles = {
        emerald: {
            bg: 'bg-emerald-50',
            text: 'text-emerald-700',
            hover: 'hover:bg-emerald-100',
            border: 'border-emerald-100',
            count: 'text-emerald-600',
            dot: 'bg-emerald-500'
        },
        blue: {
            bg: 'bg-blue-50',
            text: 'text-blue-700',
            hover: 'hover:bg-blue-100',
            border: 'border-blue-100',
            count: 'text-blue-600',
            dot: 'bg-blue-500'
        }
    };

    const color = (mode === 'attendance' || mode === 'schedules') ? styles.emerald : styles.blue;

    return (
        <div className={`bg-white rounded-2xl shadow-xl border border-gray-100 p-4 w-full ${className}`}>
            <div className="flex items-center justify-between mb-4 px-2">
                <button onClick={handlePrevMonth} className="p-1 hover:bg-gray-100 rounded-full transition-colors text-gray-400 hover:text-gray-900">
                    <ChevronLeft className="w-5 h-5" />
                </button>
                <div className="font-bold text-gray-900 capitalize text-sm">
                    {monthNames[month]} {year}
                </div>
                <button onClick={handleNextMonth} className="p-1 hover:bg-gray-100 rounded-full transition-colors text-gray-400 hover:text-gray-900">
                    <ChevronRight className="w-5 h-5" />
                </button>
            </div>

            <div className="grid grid-cols-7 gap-1 mb-2">
                {['D', 'L', 'M', 'M', 'J', 'V', 'S'].map(d => (
                    <div key={d} className="text-center text-[10px] font-bold text-gray-400 uppercase">
                        {d}
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-7 gap-2 justify-items-center relative">
                {loading && (
                    <div className="absolute inset-0 z-20 bg-white/50 backdrop-blur-[1px] flex items-center justify-center">
                        <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                    </div>
                )}
                {days.map((day, idx) => {
                    if (!day) return <div key={idx} className="w-full aspect-square" />;

                    const dateStr = generateIsoDate(day);
                    const isSelected = selectedDate === dateStr;
                    const count = dateData?.[dateStr] || internalCounts[dateStr] || 0;
                    const hasData = count > 0 || activeDates.includes(dateStr);
                    const isToday = dateStr === toLocalISO(new Date());

                    return (
                        <button
                            key={idx}
                            onClick={() => onSelectDate(dateStr)}
                            className={`
                                relative w-full aspect-square rounded-xl flex flex-col items-center justify-center transition-all duration-200
                                ${isSelected
                                    ? 'bg-blue-600 text-white shadow-md scale-105 z-10'
                                    : hasData
                                        ? `${color.bg} ${color.text} ${color.hover} border ${color.border}`
                                        : 'text-gray-700 hover:bg-gray-50 border border-transparent hover:border-gray-100'}
                                ${isToday && !isSelected ? 'ring-2 ring-blue-600 border-transparent text-blue-600' : ''}
                            `}
                        >
                            <span className={`font-bold ${isSelected || hasData ? 'text-base' : 'text-sm'} ${count > 0 && showCounters ? '-mt-1' : ''}`}>
                                {day}
                            </span>

                            {count > 0 && showCounters && (
                                <span className={`text-[10px] font-black -mt-0.5 ${isSelected ? 'text-white' : hasData ? color.count : 'text-gray-400'}`}>
                                    {count}
                                </span>
                            )}

                            {hasData && (!showCounters || count === 0) && !isSelected && (
                                <div className={`absolute bottom-1 w-1.5 h-1.5 rounded-full ${color.dot}`}></div>
                            )}
                        </button>
                    );
                })}
            </div>

            <div className="mt-4 flex items-center justify-center gap-4 text-[10px] text-gray-400 border-t border-gray-100 pt-3">
                <div className="flex items-center gap-1.5">
                    <div className={`w-1.5 h-1.5 rounded-full ${color.dot}`}></div>
                    <span>{mode === 'attendance' ? 'Con Asistencia' : mode === 'schedules' ? 'Con Horario' : 'Registrado'}</span>
                </div>
                <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 rounded-full ring-1 ring-blue-600"></div>
                    <span>Hoy</span>
                </div>
            </div>
        </div>
    );
}
